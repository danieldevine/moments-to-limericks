var moments = $('.moments');
var link = moments.find('a');
var limerick = moments.find('span.text');

link.attr('href', 'https://haiku.coderjerk.com/limrixx.php');
limerick.text('Limrixx');

